# Paper assets

This folder contains reviewer-facing figure/table/mathematical-definition assets from the 2026-07-03 R2 submission package.
It deliberately excludes cover letters, editorial response letters, declaration files, and the manuscript DOCX.

These files are provided for reproducibility and traceability of the analysis outputs, not as the publisher's version of record.
